﻿using System;
using Akka.Actors;

namespace $rootnamespace$
{
	public class $safeitemrootname$ : ReceiveActor
	{
	}
}
